# ELF Token

ELF is a community-driven meme token on Solana, inspired by the spirit of fantasy and anime.

## 📌 Token Details
- **Name**: ELF Token
- **Symbol**: ELF
- **Mint Address**: `FLoBR6MHboqTzKZJpKZLPXb2E9EBqU7x9pm7nb7jByR2`
- **Total Supply**: 1,000,000,000
- **Decimals**: 9
- **Network**: Solana

## 🔗 Links
- [Solscan](https://solscan.io/token/FLoBR6MHboqTzKZJpKZLPXb2E9EBqU7x9pm7nb7jByR2)
- [Pump.fun](https://pump.fun/coin/FLoBR6MHboqTzKZJpKZLPXb2E9EBqU7x9pm7nb7jByR2)
- [DexScreener](https://dexscreener.com/solana/gid3fwqwuk3avwpqynhif6q4elwltquntmdscmhadydh)
- [Twitter](https://twitter.com/rama_ids)

## 👛 Wallet Creator
`EK77UhsMFxYZN1hjwuTH9uhH6ADxv7ewyDA3b4idpeM6`
